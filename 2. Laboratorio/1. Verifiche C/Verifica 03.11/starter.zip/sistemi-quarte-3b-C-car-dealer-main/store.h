#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

#define MAX_LENGTH 100

// Car represents a single car in a store
typedef struct {
  // The car name
  char *name;

  // The price of the car, in €
  float price;
} Car;

/**
 * createCar creates a valid Car entity.
 *
 * @param name The name of the car, must not be empty or NULL
 * @param price The price of the car, must be > 0
 *
 * @returns The valid car, or NULL in case of any error
 */
Car *createCar(char *name, float price) {
  // implement function logic here
  return NULL;
}

/**
 * cloneCar creates a valid Car entity by copying another one.
 *
 * @param car The car to clone, must not be NULL
 *
 * @returns The cloned car, or NULL in case of any error
 */
Car *cloneCar(Car *car) {
  // implement function logic here
  return NULL;
}

/**
 * destroyCar destroys a previously created Car entity and deallocates
 * it completely.
 *
 * @param car The car to destroy, must not be NULL
 *
 * @returns -1 in case of any error, 0 otherwise
 */
int destroyCar(Car *car) {
  // implement function logic here
  return -1;
}

/**
 * serializeCar serializes the car into the specified file.
 *
 * @param car The car to serialize, must not be NULL
 * @param out_file The output file to serialize into, must not be NULL
 *
 * @returns -1 in case of any error, 0 otherwise
 */
int serializeCar(Car *car, FILE *out_file) {
  // implement function logic here
  return -1;
}

/**
 * deserializeCar deserializes the car from the specified file.
 *
 * @param in_file The output file to deserialize from, must not be NULL
 *
 * @returns The deserialized car, or NULL in case of any error
 */
Car *deserializeCar(FILE *in_file) {
  // implement function logic here
  return NULL;
}

// Store represents a car store.
typedef struct {
  // The name of the store
  char *name;

  // The name of the manager of the store
  char *manager_name;

  // The array of cars of the store
  Car *cars;

  // The store cars count
  int cars_count;
} Store;

/**
 * createStore creates a valid Store entity.
 *
 * @param name The name of the store, must not be empty or NULL
 * @param manager_name The name of the store, must not be empty or NULL
 * @param cars The array of cars, must not be NULL
 * @param cars_count The number of the cars of the store, must be > 0
 *
 * @returns The valid store, or NULL in case of any error
 */
Store *createStore(char *name, char *manager_name, Car *cars, int cars_count) {
  // implement function logic here
  return NULL;
}

/**
 * cloneStore creates a valid Store entity by copying another one.
 *
 * @param store The store to clone, must not be NULL
 *
 * @returns The cloned store, or NULL in case of any error
 */
Store *cloneStore(Store *store) {
  // implement function logic here
  return NULL;
}

/**
 * destroyStore destroys a previously created Store entity and deallocates
 * it completely.
 *
 * @param store The store to destroy, must not be NULL
 *
 * @returns -1 in case of any error, 0 otherwise
 */
int destroyStore(Store *store) {
  // implement function logic here
  return -1;
}

/**
 * serializeStore serializes the store into the specified file.
 *
 * @param store The store to serialize, must not be NULL
 * @param out_file The output file to serialize into, must not be NULL
 *
 * @returns -1 in case of any error, 0 otherwise
 */
int serializeStore(Store *store, FILE *out_file) {
  // implement function logic here
  return -1;
}

/**
 * deserializeStore deserializes the store from the specified file.
 *
 * @param in_file The output file to deserialize from, must not be NULL
 *
 * @returns The deserialized store, or NULL in case of any error
 */
Store *deserializeStore(FILE *in_file) {
  // implement function logic here
  return NULL;
}